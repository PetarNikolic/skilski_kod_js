// Prvi zadatak
let t = -32;
if((t < -15) || (t > 40)){
	console.log("Ekstremna temperatura");
}

// Drugi zadatak
let datum = new Date();
let godina = datum.getFullYear();

if(godina % 400 == 0){
	console.log("Prestupna godina");
}
else if((godina % 4 == 0) && (godina % 100 != 0)){
	console.log("Prestupna godina");
}
else{
	console.log("Nije prestupna godina");
}

// Treci zadatak
let dan = datum.getDay();
let sati = datum.getHours();

switch(dan){
	case 0:
	case 6:
		if(sati < 10 || sati >= 18){
			console.log("Ne radi");
		}
		else{
			console.log("Radi");
		}
		break;

	default:
		if(sati < 9 || sati >= 20){
			console.log("Ne radi");
		}
		else{
			console.log("Radi");
		}
}

// Cetvrti zadatak
let br1 = 10;
let br2 = 5;
let karakter = "d";

switch(karakter){
	case "m":
		console.log(br1 * br2);
		break;
	case "d":
		console.log(br1 / br2);
		break;
	case "s":
		console.log(br1 + br2);
		break;
	case "o":
		console.log(br1 - br2);
		break;
}
