window.alert("Zdravo"); // Pozdrav

document.write("Domaći zadatak broj 5")
/*
Prvi domaci zadatak
*/

let galon = 20;
let litar = galon * 3.785;
console.log(litar);

litar = 50;
console.log(litar / 3.785)

/*
	Drugi zadatak
*/

let farenhajt = 200;
let celzijus = (farenhajt - 32) * 5 / 9;
let kelvin = celzijus + 273.15;
console.log(kelvin);